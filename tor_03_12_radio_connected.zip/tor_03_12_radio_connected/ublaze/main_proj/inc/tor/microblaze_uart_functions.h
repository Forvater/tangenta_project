#ifndef MICROBLAZE_UART_FUNCTIONS_H
#define MICROBLAZE_UART_FUNCTIONS_H

#include "xuartlite_i.h"
#include "xparameters.h"

void SendByteToComPort(unsigned char byte);

#endif
