#ifndef SETTINGS_H
#define SETTINGS_H

#define LINE_LENGTH 48
#define NUMBER_OF_ACTIVE_EMITTERS 6 // 6 or 12

#endif
