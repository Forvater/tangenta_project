#ifndef CONSTANTS_H
#define CONSTANTS_H

extern const short vdx[12];
extern const short vdy[12];	
extern const short ftx[216];
extern const short fty[216];

#endif
