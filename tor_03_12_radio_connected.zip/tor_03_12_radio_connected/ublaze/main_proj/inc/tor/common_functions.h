#ifndef COMMON_FUNCTIONS_H
#define COMMON_FUNCTIONS_H

unsigned int Abs(int a);
void Swap(unsigned char* a, unsigned char* b);

#endif
