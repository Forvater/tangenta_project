//////////////////////////////////////////////////////////////////////////////
// Filename:          D:\Xilinx_Projects\tor_01\ublaze/drivers/centre_v1_00_a/src/centre.c
// Version:           1.00.a
// Description:       centre Driver Source File
// Date:              Mon Aug 06 14:29:01 2012 (by Create and Import Peripheral Wizard)
//////////////////////////////////////////////////////////////////////////////


/***************************** Include Files *******************************/

#include "centre.h"

/************************** Function Definitions ***************************/

